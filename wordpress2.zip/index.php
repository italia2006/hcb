<!DOCTYPE html>
<html>

<body>



<img src="./wp-content/hcb/main.jpeg" alt="Mountain View" style="width:100%;height:80%;">
<?php					
	include("./wp-content/hcb/loginForm.php");		
?>


</body>
</html>







